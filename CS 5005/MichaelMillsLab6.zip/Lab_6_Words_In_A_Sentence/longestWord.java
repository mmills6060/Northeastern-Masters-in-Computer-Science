public class longestWord {
    
}
