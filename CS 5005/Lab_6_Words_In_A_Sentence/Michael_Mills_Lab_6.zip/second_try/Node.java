package second_try;
// this is the node interface with linked list features 


public interface Node {
    
    Node getNext();
    void setNext(Node next);
}
