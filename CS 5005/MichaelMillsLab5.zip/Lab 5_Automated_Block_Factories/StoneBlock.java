/*
Defines a stone block
*/
public class StoneBlock extends Block {
    public StoneBlock(double weight, ResourceType type) {
        super(weight, type);
    }
}
