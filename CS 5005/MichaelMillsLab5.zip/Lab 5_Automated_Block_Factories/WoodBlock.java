/*
Defines a wood block
*/

public class WoodBlock extends Block {
    public WoodBlock(double weight, ResourceType type) {
        super(weight, type);
    }
}
