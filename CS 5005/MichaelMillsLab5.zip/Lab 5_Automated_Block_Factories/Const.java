/*
 defines the weight of each type of block
 */
public class Const {
    public static final int STONE_BLOCK_WEIGHT = 5;
    public static final int WOOD_BLOCK_WEIGHT = 2;
    public static final int HOUSE_BLOCK_WEIGHT = 10;
    public static final int HOUSE_STONE_BLOCKS = 3;
    public static final int HOUSE_WOOD_BLOCKS = 5;
    public static final double STONE_WEIGHT = 5.0;
    public static final double WOOD_WEIGHT = 2.5;
}
