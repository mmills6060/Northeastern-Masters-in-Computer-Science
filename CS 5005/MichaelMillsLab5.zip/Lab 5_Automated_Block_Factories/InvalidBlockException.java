/*
handles the invalid block exception error.
*/
public class InvalidBlockException extends Exception {
    public InvalidBlockException(String message) {
        super(message);
    }
}
