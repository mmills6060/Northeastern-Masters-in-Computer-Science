/*
Defines all of the possibel types of resources.
*/
import java.util.Random; 
import java.lang.Math;

public enum ResourceType {
    STONE,
    WOOD,
    HOUSE
}